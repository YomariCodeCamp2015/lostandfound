package com.itspossible.connection;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Helper {
	Context context;
	
	public boolean isOnline(Context c) {
		ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnectedOrConnecting()) {
//			if (netInfo.getType() != ConnectivityManager.TYPE_WIFI) {
//				Toast.makeText(this, "This app doesn't work without wifi", Toast.LENGTH_LONG).show();
//				return false;
//			}
			return true;
		} else {
			return false;
		}
	}

	public String getIp() {
		// TODO Auto-generated method stub
	return ("http://192.168.0.101/");
		//return "192.168.1.25";

	}
}
