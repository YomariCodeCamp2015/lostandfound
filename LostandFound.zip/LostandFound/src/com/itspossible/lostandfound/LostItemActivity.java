package com.itspossible.lostandfound;



import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.itspossible.connection.Helper;
import com.itspossible.connection.HttpManager;
import com.itspossible.connection.RequestPackage;

public class LostItemActivity extends Activity {
	JSONArray contacts = null;
    Spinner choosecata;
    ListView listView;
   // ArrayList<Car> arrayCars;
	//ListView listViewCars;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_lost_item);
		listView = (ListView) findViewById(R.id.listview);
		android.app.ActionBar ab = getActionBar();
		ColorDrawable colorDrawable = new ColorDrawable(
				Color.parseColor("#009688"));
		ab.setBackgroundDrawable(colorDrawable);
		choosecata = (Spinner) findViewById(R.id.spinner1);
		 
		
		// Create an ArrayAdapter using the string array and a default spinner layout
		ArrayAdapter<CharSequence> saerchadapter = ArrayAdapter.createFromResource(this,
		        R.array.searchitem, android.R.layout.simple_spinner_item);
		
		// Specify the layout to use when the list of choices appears
		saerchadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		
		// Apply the adapter to the spinner
		choosecata.setAdapter(saerchadapter);
		
		if (new Helper().isOnline(getApplicationContext())) {
			RequestPackage p = new RequestPackage();

			p.setMethod("GET");
			MyTask task = new MyTask();
			p.setUri("http://yomarihakathan.cinemandu.com/page/page");
			 task.execute(p);
			

			// requestData("http://192.168.43.137/gharbhal/comments.php");
		} else {
			Toast.makeText(getApplicationContext(), "Network isn't available",
					Toast.LENGTH_LONG).show();
		}

		
	}

	public class MyTask extends AsyncTask<RequestPackage, String, String> {
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
		}

		@Override
		protected String doInBackground(RequestPackage... params) {
			HttpManager hm2 = new HttpManager();
			String ressult = hm2.getData(params[0]);
			return ressult;
		}
		@Override
		protected void onPostExecute(String result) {
			// TODO Auto-generated method stub
			Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
			ArrayList<String> arr=new ArrayList<String>();
			//{"success":1,"message":"Post Available!","posts":[{"post_id":"20","username":"roshan","title":"Hostel","price":"222","lngg":"85.303605","latt":"27.68719","message":"dgr\n"},{"post_id":"21","username":"paras","title":"hostel","price":"2000","lngg":"85.3026731000000137","latt":"27.6868763","message":"hjgffffffffhjgfhdsf"},{"post_id":"22","username":"a","title":"hostel","price":"2000","lngg":"85.3026731000000189","latt":"27.6868799","message":"hjgffffffffhjgfhdsf"}]}
			 
			try {
				
				JSONObject regObj = new JSONObject(result);
				JSONObject j1=regObj.getJSONObject("data");
				
				  
				 // if (regObj.getString("success").equals("1")) { 
					 // String suceeregmessage= regObj.getString("message"); 
					  JSONArray contacts = j1.getJSONArray("lost_properties");
					 // array=new String[contacts.length()];
					  for (int i = 0; i < contacts.length(); i++) {
				  
				       JSONObject c = contacts.getJSONObject(i);
				       String name =c.getString("name");
						Toast.makeText(getApplicationContext(), name, Toast.LENGTH_LONG).show();

						arr.add(name);
//				       String uid=c.getString("username");
//				       String prid=c.getString("price");
//				       double value = Double.parseDouble(prid);
//				       String tid=c.getString("title");
				       
				      // items.add(new Items("tid", prid, uid));
				      
				       ArrayAdapter<String> myArrayadapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_dropdown_item_1line,arr);
						listView.setAdapter(myArrayadapter);
						
				      
					  }
				  //}
				 
				
			} catch (JSONException e) {
				e.printStackTrace();	// TODO: handle exception
			}
			  
			
			
		
		 

	}

	}}
