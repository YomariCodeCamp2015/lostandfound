package com.itspossible.lostandfound;



import org.json.JSONException;
import org.json.JSONObject;

import com.itspossible.connection.Helper;
import com.itspossible.connection.HttpManager;
import com.itspossible.connection.RequestPackage;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends Activity {
	EditText  username, password, email,phone;
	Button register;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		register = (Button) findViewById(R.id.btn_regacc);
		// Edit Text
		

		username = (EditText) findViewById(R.id.edit_runame);
		password = (EditText) findViewById(R.id.edit_rpass);
		email = (EditText) findViewById(R.id.edit_remail);
		
		phone = (EditText) findViewById(R.id.edit_rphone);

		register.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (new Helper().isOnline(getApplicationContext())) {
					requestData(new Helper().getIp()+"wakathon/registersuccess.json");
				} else {
					Toast.makeText(getApplicationContext(),
							"Network isn't available", Toast.LENGTH_LONG)
							.show();
				}
			}

			private void requestData(String uri) {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), uri, Toast.LENGTH_LONG)
						.show();
				RequestPackage p = new RequestPackage();

				String Username = username.getText().toString();
				String Password = password.getText().toString();
				
				String emailadd = email.getText().toString();
				
				String Phone = phone.getText().toString();
				

				p.setParam("username", Username);
				p.setParam("password", Password);
				
				p.setParam("email", emailadd);
			
				p.setParam("phone", Phone);
				p.setMethod("POST");
				WelcomeTask task = new WelcomeTask();
				p.setUri(uri);
				task.execute(p);
			}

			// }
		});
	}
	public class WelcomeTask extends AsyncTask<RequestPackage, String, String>{
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			  
		}
		

		@Override
		protected String doInBackground(RequestPackage... params) {
			// TODO Auto-generated method stub
			HttpManager hm2 = new HttpManager();
			String ressult = hm2.getData(params[0]);
			return ressult;
		}
		@Override
		protected void onPostExecute(String result) {

			Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
			try{

	JSONObject regObj = new JSONObject(result);
	//System.out.println(regObj);
	if(regObj.getString("status").equals(1)) {
	//String message =regObj.getString("message");
	Toast.makeText(getApplicationContext(), "Register Suceesful", Toast.LENGTH_SHORT).show();
	//Intent ir= new Intent(PostActivity.this,RealPostActivity.class);
	//ir.putExtra("member_id",member_iid);
	//startActivity(ir);
	//mProgressDialog.dismiss();
	}
	if(regObj.getString("status").equals(0)) {
		//String message =regObj.getString("message");
		Toast.makeText(getApplicationContext(), "", Toast.LENGTH_SHORT).show();
}
	       
	}catch(JSONException e) {

	e.printStackTrace();

	}
}
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.register, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
