package com.itspossible.lostandfound;



import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.itspossible.connection.Helper;
import com.itspossible.connection.HttpManager;
import com.itspossible.connection.RequestPackage;

public class ReportLostActivity extends Activity{
	Button register ,login;
	EditText email,password;
	ProgressDialog mProgressDialog;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_report_lost);
		login= (Button) findViewById(R.id.btn_login);
		register= (Button) findViewById(R.id.btn_reg);
		//identifying edit text
        email =(EditText)findViewById(R.id.edit_signinuname);
	    password =(EditText)findViewById(R.id.edit_signinpass);
		//login button click listner
		login.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if (new Helper().isOnline(getApplicationContext()))
				{ //  requestData(new Helper().getIp()+"gharbhal/login.php");
					//requestData(new Helper().getIp()+"wakathon/loginsuccess.json");
					requestData("http://yomarihakathan.cinemandu.com/user/userlogin");
					//requestDatafail(new Helper().getIp()+"wakathon/loginfailure.json");
				}
				else {
					Toast.makeText(getApplicationContext(), "Network isn't available", Toast.LENGTH_LONG).show();
				}
				
			}
			private void requestData(String uri) {
				// TODO Auto-generated method stub
			Toast.makeText(getApplicationContext(), uri, Toast.LENGTH_SHORT).show();	
			RequestPackage p = new RequestPackage();
            p.setMethod("POST");
           WelcomeTask task = new WelcomeTask();
          // task.execute(p);
          
          String  uname = email.getText().toString();
          String pass = password.getText().toString();
          if(email.getText().toString().trim().length() == 0) {
              Toast.makeText(getApplicationContext(), "Please Enter username", Toast.LENGTH_LONG).show();
              email.setError("please enter username");
              
          }if(password.getText().toString().trim().length() == 0){
              Toast.makeText(getApplicationContext(), "Please Enter password", Toast.LENGTH_LONG).show();
              
          } else{
        	   p.setParam("email", uname);
        	   p.setParam("password", pass); 
        	   p.setUri(uri);
              task.execute(p);
        	  
         

			}
			}

			
		});
		//register button click listner
		register.setOnClickListener( new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent ro= new Intent(ReportLostActivity.this,RegisterActivity.class);
				startActivity(ro);
			}
		});
		android.app.ActionBar ab = getActionBar();
		ColorDrawable colorDrawable = new ColorDrawable(
				Color.parseColor("#009688"));
		ab.setBackgroundDrawable(colorDrawable);
	}
	public class WelcomeTask extends AsyncTask<RequestPackage, String, String>{
		@Override
		protected void onPreExecute() {
			// TODO Auto-generated method stub
			super.onPreExecute();
			  
		}
		

		@Override
		protected String doInBackground(RequestPackage... params) {
			// TODO Auto-generated method stub
			HttpManager hm2 = new HttpManager();
			String ressult = hm2.getData(params[0]);
			return ressult;
		}
		@Override
		protected void onPostExecute(String result) {
			Intent ir= new Intent(ReportLostActivity.this,PostPropertyActivity.class);
			//ir.putExtra("member_id",member_iid);
			startActivity(ir);
			/*Toast.makeText(getApplicationContext(), result, Toast.LENGTH_LONG).show();
			try{

	JSONObject regObj = new JSONObject(result);
	//System.out.println(regObj);
	if(regObj.getString("status").equals("1")) {
	String message =regObj.getString("message");
		
		mProgressDialog.dismiss();
		}if(regObj.getString("success").equals("0")) {
			String message1 =regObj.getString("message");
			Toast.makeText(getApplicationContext(), message1, Toast.LENGTH_SHORT).show();
			mProgressDialog.dismiss();
		}
		
	  
		       
		}catch(JSONException e) {

		e.printStackTrace();

		}*/
}
		
	}

}

